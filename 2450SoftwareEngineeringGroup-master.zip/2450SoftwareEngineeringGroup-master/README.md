# 2450SoftwareEngineeringGroup
Group for Summer2016 Software Engineering Project

Hangouts Chatroom: https://hangouts.google.com/
Google Drive Link: https://drive.google.com/open?id=0B4PL1dJ8WuvCLUNxNmRFeENVQ1E

Please look at the "Issues" tab for current code issues/to-do's. If you are going to take an issue, please comment on it saying that 
you're going to be taking the task.
